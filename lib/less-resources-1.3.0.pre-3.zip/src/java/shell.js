function print(text) {
    Packages.com.groovydev.less.Shell.print(text);
}
function quit() {}
function readFile(filename) {
    return new String(Packages.com.groovydev.less.Shell.readFile(filename));
}
function readUrl(filename) {
    return new String(Packages.com.groovydev.less.Shell.readUrl(filename));
}
function writeFile(filename, text) {
    Packages.com.groovydev.less.Shell.writeFile(filename, text);
}
